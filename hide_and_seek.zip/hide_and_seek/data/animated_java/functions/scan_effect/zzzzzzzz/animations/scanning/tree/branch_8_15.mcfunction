execute if score @s aj.anim_time matches 8 run function animated_java:scan_effect/zzzzzzzz/animations/scanning/tree/leaf_8
execute if score @s aj.anim_time matches 9 run function animated_java:scan_effect/zzzzzzzz/animations/scanning/tree/leaf_9
execute if score @s aj.anim_time matches 10 run function animated_java:scan_effect/zzzzzzzz/animations/scanning/tree/leaf_10
execute if score @s aj.anim_time matches 11 run function animated_java:scan_effect/zzzzzzzz/animations/scanning/tree/leaf_11
execute if score @s aj.anim_time matches 12 run function animated_java:scan_effect/zzzzzzzz/animations/scanning/tree/leaf_12
execute if score @s aj.anim_time matches 13 run function animated_java:scan_effect/zzzzzzzz/animations/scanning/tree/leaf_13
execute if score @s aj.anim_time matches 14 run function animated_java:scan_effect/zzzzzzzz/animations/scanning/tree/leaf_14
execute if score @s aj.anim_time matches 15 run function animated_java:scan_effect/zzzzzzzz/animations/scanning/tree/leaf_15